from django.urls import path
from .views import index, top-sellers

urlspatterns=[
   path(' ', index, name="main-page")
   path('top-sellers/', top-sellers, name="top-sellers")
]